extends SceneTree
func _initialize(): call_deferred("bake")
func bake():
	var registration = JSON.parse_string(FileAccess.get_file_as_string("res://registration.json"))
	var viewport = SubViewport.new()
	viewport.size = Vector2i(320,320)
	viewport.transparent_bg = true
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	for who in ["peanut","hutch"]:
		DirAccess.make_dir_recursive_absolute("res://baked/"+who)
		var legs = Sprite2D.new()
		legs.centered = false
		legs.region_enabled = true
		var mat = ShaderMaterial.new()
		mat.shader = load("res://legs.gdshader")
		mat.set_shader_parameter("leg_color",Vector3(0.72,0.48,0.20) if who=="peanut" else Vector3(0.29,0.40,0.50))
		mat.set_shader_parameter("foot_color",Vector3(0.38,0.23,0.10) if who=="peanut" else Vector3(0.91,0.92,0.87))
		legs.material = mat
		viewport.add_child(legs)
		var rig=Node2D.new()
		rig.set_script(load("res://rig.gd"))
		rig.character=who
		rig.animate=false
		viewport.add_child(rig)
		for state in registration:
			legs.texture=load("res://references/"+state+".png")
			rig.animation=state
			var sheet=Image.create(2560,2560,false,Image.FORMAT_RGBA8)
			for i in range(registration[state].size()):
				var reg=registration[state][i]
				var hip=Vector2(reg.hip[0],reg.hip[1])
				var cell=Vector2((i%8)*320,(i/8)*320)
				legs.region_rect=Rect2(cell,Vector2(320,320))
				mat.set_shader_parameter("cell",cell)
				mat.set_shader_parameter("hip",hip)
				mat.set_shader_parameter("leg_axis",Vector2(reg.axis[0],reg.axis[1]))
				rig.sample_pose(i/30.0)
				rig.root_pose.rotation=0
				rig.root_pose.position=Vector2.ZERO
				rig.position=hip+Vector2(0,58)
				rig.upper.rotation=reg.angle
				await process_frame
				await RenderingServer.frame_post_draw
				sheet.blit_rect(viewport.get_texture().get_image(),Rect2i(0,0,320,320),Vector2i(cell))
			sheet.save_png("res://baked/%s/%s.png" % [who,state])
			print("BAKED ",who," ",state)
		legs.queue_free()
		rig.queue_free()
		await process_frame
	quit()
