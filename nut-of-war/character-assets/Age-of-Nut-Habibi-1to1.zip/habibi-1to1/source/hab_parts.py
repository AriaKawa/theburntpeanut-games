import cv2,numpy as np
HD=r"C:/Users/Swagg/AppData/Local/Temp/claude/C--Users-Swagg-Documents-Playground-crossroads-2/361eb09e-cf9d-4075-915a-df6aaa9f6559/scratchpad/hab/"
im=cv2.imread(HD+'habibi-aow-parts-v1.png',cv2.IMREAD_UNCHANGED)
def crops():
    a=im[...,3]; n,lab,st,cen=cv2.connectedComponentsWithStats((a>200).astype(np.uint8))
    out={}
    for i in range(1,n):
        if st[i,4]<2000: continue
        cx,cy=cen[i]; col,row=int(cx//384),int(cy//512)
        name={(0,0):'head',(1,0):'torso',(2,0):'upper',(3,0):'fore',(0,1):'thigh',(1,1):'shin'}.get((col,row),'launcher')
        x,y,w,h=st[i,:4]; P=6
        m=cv2.dilate((lab==i).astype(np.uint8),np.ones((3,3),np.uint8))
        c=im.copy(); c[...,3]=np.minimum(c[...,3],m*255)
        out[name]=(c[y-P:y+h+P,x-P:x+w+P].copy(),(x-P,y-P))
    return out
