"""Habibi on the Age of War military rifleman puppet (unit 552): 7 pieces posed by the SWF timeline."""
import json,sys,numpy as np,cv2
HD=r"C:/Users/Swagg/AppData/Local/Temp/claude/C--Users-Swagg-Documents-Playground-crossroads-2/361eb09e-cf9d-4075-915a-df6aaa9f6559/scratchpad/hab/"
sys.path.insert(0,HD)
from hab_parts import crops
SRC=json.load(open(HD+'mil_anims.json'))
C={k:v[0] for k,v in crops().items()}; K=24.0
def canon_affine(src,p0h,p1h,p0l,p1l,perp_scale=None):
    p0h,p1h,p0l,p1l=map(lambda v:np.array(v,float),(p0h,p1h,p0l,p1l))
    ah=p1h-p0h; Lh=np.hypot(*ah); ah/=Lh; ph=np.array([-ah[1],ah[0]])
    al=p1l-p0l; Ll=np.hypot(*al); al/=Ll; pl=np.array([-al[1],al[0]])
    sa=Ll/Lh; sp=perp_scale if perp_scale else sa
    L=np.stack([al*sa,pl*sp],1)@np.stack([ah,ph]); t=p0l-L@p0h
    H,W=src.shape[:2]; lc=np.array([[0,0],[W,0],[0,H],[W,H]],float)@L.T+t
    lo=np.floor(lc.min(0))-1; hi=np.ceil(lc.max(0))+1
    G=np.array([[K,0,-lo[0]*K],[0,K,-lo[1]*K]])
    M=np.concatenate([G[:,:2]@L,(G[:,:2]@t+G[:,2])[:,None]],1)
    out=cv2.warpAffine(src,M,(int((hi[0]-lo[0])*K),int((hi[1]-lo[1])*K)),flags=cv2.INTER_LINEAR,borderValue=(0,0,0,0))
    return out,-lo*K
PARTS={
 505:canon_affine(C['head'],(190,8),(165,300),(8.0,-1.2),(5.5,13.6)),
 511:canon_affine(C['torso'],(95,60),(125,380),(12.13,12.28),(9.75,26.56)),
 501:canon_affine(C['upper'],(100,25),(110,290),(7.82,5.25),(3.93,14.69)),
 503:canon_affine(C['fore'],(60,30),(100,345),(1.61,2.03),(13.0,4.2)),
 507:canon_affine(C['thigh'],(90,25),(90,380),(5.1,4.32),(8.72,14.96)),
 509:canon_affine(C['shin'],(75,30),(95,405),(6.64,2.58),(2.95,18.94)),
 520:canon_affine(C['launcher'],(318,150),(665,88),(12.5,9.5),(34.9,7.0)),
}
# head drawn just in front of the torso (the beard overlaps the collar); everything else keeps SWF depth order
ORDER={1:1,4:4,6:15.5,9:9,12:12,15:15,18:18,21:21,24:24,26:26,29:29}
SHOOT_HOLD=32   # attack = 21 shoot frames then hold, 53 frames = 1.33 s at 40 fps (same rocket rate as before)
def attack_frames(): return [('shoot',k) for k in range(21)]+[('shoot',20)]*SHOOT_HOLD
A={'idle':SRC['idle'],'walk':SRC['walk'],'die':SRC['die'],'shoot':SRC['shoot']}
def mul(P,Cm):
    a,b,c,d_,tx,ty=P; A2,B,Cc,D,TX,TY=Cm
    return (a*A2+c*B, b*A2+d_*B, a*Cc+c*D, b*Cc+d_*D, a*TX+c*TY+tx, b*TX+d_*TY+ty)
FW,FH,PX,PY,U=384,256,192,225,3.0; SS=2
def place_list(anim,k):
    if anim=='attack': anim,k=attack_frames()[k]
    return sorted((x for x in A[anim][k] if x['char'] in PARTS),key=lambda x:ORDER.get(x['depth'],x['depth']))
def frame_list(anim): return range(53 if anim=='attack' else len(A[anim]))
def frame(anim,k):
    W,H=FW*SS,FH*SS; acc=np.zeros((H,W,4),np.float32)
    for x in place_list(anim,k):
        img,org=PARTS[x['char']]
        m=mul((U*SS,0,0,U*SS,PX*SS,PY*SS),tuple(x['m']))
        L=np.array([[m[0],m[2]],[m[1],m[3]]])/K; t=np.array([m[4],m[5]])-L@org
        w=cv2.warpAffine(img,np.concatenate([L,t[:,None]],1),(W,H),flags=cv2.INTER_LINEAR,borderValue=(0,0,0,0)).astype(np.float32)
        a=w[...,3:4]/255; acc[...,:3]=acc[...,:3]*(1-a)+w[...,:3]*a; acc[...,3:4]=acc[...,3:4]*(1-a)+w[...,3:4]
    pm=acc.copy(); pm[...,:3]*=acc[...,3:4]/255; pm=cv2.resize(pm,(FW,FH),interpolation=cv2.INTER_AREA)
    al=pm[...,3:4]; rgb=np.where(al>0.5,pm[...,:3]/np.maximum(al,1e-3)*255,0)
    return np.clip(np.concatenate([rgb,al],2),0,255).astype(np.uint8)
def muzzle(k):
    """launcher tip in frame px for attack frame k"""
    x=[e for e in place_list('attack',k) if e['char']==520][0]; m=mul((U,0,0,U,PX,PY),tuple(x['m']))
    p=np.array([34.9,7.0]); return (m[0]*p[0]+m[2]*p[1]+m[4], m[1]*p[0]+m[3]*p[1]+m[5])
