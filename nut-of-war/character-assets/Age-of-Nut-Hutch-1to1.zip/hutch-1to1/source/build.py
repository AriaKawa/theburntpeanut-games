import json,sys,numpy as np,cv2
from hparts import crops
R=r"C:/Users/Swagg/AppData/Local/Temp/claude/C--Users-Swagg--claude-spares-spare-Xk65bd/361eb09e-cf9d-4075-915a-df6aaa9f6559/scratchpad/rig/"
A=json.load(open(R+'swf_anims.json'))
C=crops(); K=24.0  # canonical px per local unit
def canon_affine(src,p0h,p1h,p0l,p1l,perp_scale=None,bounds=None):
    """non-uniform map: along p0->p1 axis and its perpendicular. returns canonical image + origin(px) of local (0,0)."""
    p0h,p1h,p0l,p1l=map(lambda v:np.array(v,float),(p0h,p1h,p0l,p1l))
    ah=p1h-p0h; Lh=np.hypot(*ah); ah/=Lh; ph=np.array([-ah[1],ah[0]])
    al=p1l-p0l; Ll=np.hypot(*al); al/=Ll; pl=np.array([-al[1],al[0]])
    sa=Ll/Lh; sp=perp_scale if perp_scale else sa   # local units per hutch px
    # local = p0l + al*sa*((h-p0h).ah) + pl*sp*((h-p0h).ph)
    Mh=np.stack([ah,ph]); Ml=np.stack([al*sa,pl*sp],1)   # local = p0l + Ml @ (Mh @ (h-p0h))
    L=Ml@Mh; t=p0l-L@p0h
    H,W=src.shape[:2]; corners=np.array([[0,0],[W,0],[0,H],[W,H]],float)
    lc=corners@L.T+t; lo=np.floor(lc.min(0))-1; hi=np.ceil(lc.max(0))+1
    G=np.array([[K,0,-lo[0]*K],[0,K,-lo[1]*K]])
    M=G[:,:2]@L; M=np.concatenate([M,(G[:,:2]@t+G[:,2])[:,None]],1)
    size=(int((hi[0]-lo[0])*K),int((hi[1]-lo[1])*K))
    out=cv2.warpAffine(src,M,size,flags=cv2.INTER_LINEAR,borderValue=(0,0,0,0))
    return out,-lo*K
def canon_shin(src):
    knee=(86,45); seam_h=290; sole_h=355; sx=32.0
    seam_l=14.2-(sole_h-seam_h)/sx; sj=(seam_h-knee[1])/seam_l
    lo=np.array([-4.0,-3.0]); hi=np.array([7.0,15.2])
    W,H=int((hi[0]-lo[0])*K),int((hi[1]-lo[1])*K)
    X,Y=np.meshgrid(np.arange(W),np.arange(H)); lx=X/K+lo[0]; ly=Y/K+lo[1]
    hy=np.where(ly<seam_l,knee[1]+ly*sj,sole_h-(14.2-ly)*sx); hx=knee[0]+lx*sx
    out=cv2.remap(src,hx.astype(np.float32),hy.astype(np.float32),cv2.INTER_LINEAR,borderValue=(0,0,0,0))
    return out,-lo*K
def fatten(img,base=1.2,belly=0.62,at=0.72,width=0.26):
    """widen a right-facing torso from its back edge, most at the belly"""
    H,W=img.shape[:2]; y=np.arange(H)/H
    f=base+belly*np.exp(-((y-at)/width)**2)
    OW=int(np.ceil(W*f.max()))+4
    X,Y=np.meshgrid(np.arange(OW,dtype=np.float32),np.arange(H,dtype=np.float32))
    sx=(X/f[:,None]).astype(np.float32)
    return cv2.remap(img,sx,Y,cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT,borderValue=(0,0,0,0)),f
FAT=True
def body():
    t=C['torso']; h=C['head']
    sh,hp=np.array([130.,70.]),np.array([150.,410.])
    if FAT:
        t,f=fatten(t); sh[0]*=f[int(sh[1])]; hp[0]*=f[int(hp[1])]
    th,tw=t.shape[:2]; hh,hw=h.shape[:2]
    oy=232; ox=8   # head sits low enough that beard and hair meet the collar
    W=max(tw,hw+ox); H=th+oy
    can=np.zeros((H,W,4),np.float32)
    def over(img,x,y):
        img=img.astype(np.float32); a=img[...,3:4]/255; reg=can[y:y+img.shape[0],x:x+img.shape[1]]
        reg[...,:3]=reg[...,:3]*(1-a)+img[...,:3]*a; reg[...,3:4]=reg[...,3:4]*(1-a)+img[...,3:4]*a
    neck=np.zeros((H,W,4),np.uint8)
    pts=np.array([[ox+92,200],[ox+190,190],[ox+200,oy+70],[ox+80,oy+70]],np.int32)
    cv2.fillPoly(neck,[pts],(150,190,232,255)); cv2.polylines(neck,[pts],True,(10,10,10,255),9,cv2.LINE_AA)
    over(neck,0,0); over(t,0,oy); over(h,ox,0)
    can=np.clip(can,0,255).astype(np.uint8)
    return canon_affine(can,(sh[0],sh[1]+oy),(hp[0],hp[1]+oy),(-1.4,-2.4),(-0.5,8.05))
PARTS={
 219:canon_affine(C['thigh'],(79,42),(75,329),(0,0),(0,8.4),perp_scale=8.4/287*1.35),
 221:canon_shin(C['shin']),
 227:canon_affine(C['upper'],(76,43),(88,303),(0,0),(0,8.65),perp_scale=8.65/260*1.12),
 229:canon_affine(C['grip'],(64,37),(115,342),(0,0),(0.12,8.75)),
 233:canon_affine(C['fist'],(66,40),(108,335),(0,0),(0.8,10.0)),
 225:canon_affine(C['club'],(14,40),(448,104),(0,4.3),(0,-19.5),perp_scale=6.0/150),
 223:body(),
}
def mul(P,Cm):
    a,b,c,d_,tx,ty=P; A2,B,Cc,D,TX,TY=Cm
    return (a*A2+c*B, b*A2+d_*B, a*Cc+c*D, b*Cc+d_*D, a*TX+c*TY+tx, b*TX+d_*TY+ty)
FW,FH,PX,PY,U=384,256,192,236,4.0   # frame, ground pivot, px per unit
SS=2
def frame(anim,k):
    W,H=FW*SS,FH*SS; acc=np.zeros((H,W,4),np.float32)
    for x in A[anim][k]:
        if x['char'] not in PARTS: continue
        img,org=PARTS[x['char']]
        m=mul((U*SS,0,0,U*SS,PX*SS,PY*SS),tuple(x['m']))
        L=np.array([[m[0],m[2]],[m[1],m[3]]])/K
        t=np.array([m[4],m[5]])-L@org
        w=cv2.warpAffine(img,np.concatenate([L,t[:,None]],1),(W,H),flags=cv2.INTER_LINEAR,borderValue=(0,0,0,0)).astype(np.float32)
        a=w[...,3:4]/255; acc[...,:3]=acc[...,:3]*(1-a)+w[...,:3]*a; acc[...,3:4]=acc[...,3:4]*(1-a)+w[...,3:4]
    # premultiplied downsample
    pm=acc.copy(); pm[...,:3]*=acc[...,3:4]/255
    pm=cv2.resize(pm,(FW,FH),interpolation=cv2.INTER_AREA)
    al=pm[...,3:4]; rgb=np.where(al>0.5,pm[...,:3]/np.maximum(al,1e-3)*255,0)
    return np.clip(np.concatenate([rgb,al],2),0,255).astype(np.uint8)
