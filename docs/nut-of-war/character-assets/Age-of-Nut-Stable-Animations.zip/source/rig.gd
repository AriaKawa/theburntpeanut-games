extends Node2D
## Editable cutout master. Animation names match the original melee_unit.gd.
@export_enum("peanut", "hutch") var character: String = "peanut"
@export_enum("idle", "walk", "attack", "die") var animation: String = "walk"
@export var animate: bool = true
var clock: float = 0.0
var joints: Dictionary = {}
var root_pose: Node2D
var upper: Node2D
var atlas: Texture2D
var part_regions: Array[Rect2]
const LENGTHS = {"idle": 50.0/30, "walk": 43.0/30, "attack": 40.0/30, "die": 23.0/30}

func _ready():
	atlas = load("res://%s-parts.png" % character)
	if character == "peanut":
		part_regions = [Rect2(70,45,285,515),Rect2(390,130,365,355),Rect2(880,155,145,300),Rect2(1275,145,160,345),Rect2(80,600,235,360),Rect2(475,620,160,325),Rect2(780,745,240,200),Rect2(1060,725,455,160)]
	else:
		part_regions = [Rect2(55,65,305,440),Rect2(425,125,340,330),Rect2(865,115,210,365),Rect2(1250,75,180,440),Rect2(90,540,210,440),Rect2(485,560,180,420),Rect2(775,740,280,160),Rect2(1080,725,450,160)]
	root_pose = Node2D.new()
	root_pose.name = "Pose"
	add_child(root_pose)
	leg("Rear", -7, true)
	upper = joint("Upper",root_pose,Vector2(0,-58))
	arm("Rear", true)
	var body = joint("Torso", upper, Vector2.ZERO)
	if character == "peanut":
		piece(body,0,Vector2(43,107),Vector2(-21,-102))
		var helmet = joint("Helmet",body,Vector2(0,-107))
		piece(helmet,1,Vector2(49,47),Vector2(-25,-8))
	else:
		piece(body,0,Vector2(53,70),Vector2(-28,-67))
		var head = joint("Head",body,Vector2(-2,-56))
		piece(head,1,Vector2(48,47),Vector2(-20,-43))
	leg("Front", 6, false)
	arm("Front", false)
	sample_pose(0.0)

func joint(label: String, parent_node: Node2D, at: Vector2) -> Node2D:
	var node = Node2D.new()
	node.name = label
	node.position = at
	parent_node.add_child(node)
	joints[label] = node
	return node

func piece(parent_node: Node2D, part: int, size: Vector2, at: Vector2):
	var sprite = Sprite2D.new()
	sprite.name = "Part%d" % part
	sprite.texture = atlas
	sprite.region_enabled = true
	sprite.region_rect = part_regions[part]
	sprite.centered = false
	sprite.position = at
	sprite.scale = size / part_regions[part].size
	var material = ShaderMaterial.new()
	material.shader = preload("res://cutout.gdshader")
	sprite.material = material
	parent_node.add_child(sprite)

func leg(side: String, x: float, rear: bool):
	var hip = joint(side+"Hip",root_pose,Vector2(x,-59))
	if rear: hip.modulate = Color(0.8,0.8,0.8)
	piece(hip,4,Vector2(22,34),Vector2(-11,-4))
	var knee = joint(side+"Knee",hip,Vector2(0,27))
	piece(knee,5,Vector2(18,33),Vector2(-9,-4))
	var ankle = joint(side+"Ankle",knee,Vector2(0,26))
	piece(ankle,6,Vector2(27,17),Vector2(-10,-5))

func arm(side: String, rear: bool):
	var shoulder = joint(side+"Shoulder",upper,Vector2(-5,-49 if character=="peanut" else -54))
	if rear: shoulder.modulate = Color(0.8,0.8,0.8)
	piece(shoulder,2,Vector2(17,32),Vector2(-8,-5))
	var elbow = joint(side+"Elbow",shoulder,Vector2(0,24))
	piece(elbow,3,Vector2(18,36),Vector2(-8,-4))
	if not rear:
		var hand = joint("Weapon",elbow,Vector2(2,26))
		piece(hand,7,Vector2(62,20),Vector2(-7,-7))

func _process(delta):
	if animate:
		clock += delta
		sample_pose(clock)

func keyed(frame: float, keys: Array) -> float:
	for i in range(1, keys.size()):
		if frame <= keys[i][0]:
			var t = clampf((frame-keys[i-1][0])/(keys[i][0]-keys[i-1][0]),0,1)
			t = t*t*(3-2*t)
			return lerpf(keys[i-1][1], keys[i][1], t)
	return keys[-1][1]

func sample_pose(time: float):
	if not is_instance_valid(root_pose): return
	for j in joints.values(): j.rotation = 0.0
	root_pose.position = Vector2.ZERO
	root_pose.rotation = 0.0
	var f = time*30.0
	var phase = fmod(time,float(LENGTHS[animation])) / float(LENGTHS[animation])
	var wave = sin(phase*TAU)
	# Fixed torso/head pixels; only rigid transforms, never per-frame redraws.
	joints.FrontShoulder.rotation = -0.12
	joints.FrontElbow.rotation = -0.32
	joints.Weapon.rotation = 0.44
	if animation == "idle":
		joints.FrontElbow.rotation += wave*0.018
		joints.Weapon.rotation -= wave*0.018
	elif animation == "walk":
		for side in ["Front","Rear"]:
			var swing = wave if side=="Front" else -wave
			joints[side+"Hip"].rotation = swing*0.48
			joints[side+"Knee"].rotation = -maxf(0.0,swing)*0.65
			joints[side+"Ankle"].rotation = -joints[side+"Hip"].rotation-joints[side+"Knee"].rotation
		joints.RearShoulder.rotation = wave*0.13
		joints.FrontShoulder.rotation += wave*0.07
		joints.Weapon.rotation -= wave*0.07
	elif animation == "attack":
		# Original: lift 0-8, hold 8-16, swing 17-20, recover 25-39.
		upper.rotation = keyed(f,[[0,0],[16,0],[20,0.38],[25,0.38],[39,0]])
		joints.FrontShoulder.rotation = keyed(f,[[0,-0.12],[7,-2.5],[16,-2.5],[18,-1.95],[19,-1.35],[20,-0.7],[25,-0.7],[39,-0.12]])
		joints.FrontElbow.rotation = keyed(f,[[0,-0.32],[7,-0.8],[16,-0.8],[19,-0.25],[20,0.0],[25,0.0],[39,-0.32]])
		joints.RearShoulder.rotation = keyed(f,[[0,0],[8,-1.2],[16,-1.2],[20,0.55],[25,0.55],[39,0]])
		var weapon_angle = keyed(f,[[0,0],[4,-1.4],[8,-3.0],[16,-3.0],[18,-0.9],[19,0],[20,0.65],[25,0.65],[39,0]])
		joints.Weapon.rotation = weapon_angle-upper.rotation-joints.FrontShoulder.rotation-joints.FrontElbow.rotation
	elif animation == "die":
		var fall = clampf(f/22.0,0.0,1.0)
		root_pose.rotation = -smoothstep(0.12,0.95,fall)*PI/2.0
		root_pose.position.y = -5*fall
		joints.FrontShoulder.rotation = -fall*1.0
		joints.RearShoulder.rotation = -fall*0.7
		joints.FrontHip.rotation = -sin(fall*PI)*0.4
		joints.FrontKnee.rotation = -sin(fall*PI)*0.7
