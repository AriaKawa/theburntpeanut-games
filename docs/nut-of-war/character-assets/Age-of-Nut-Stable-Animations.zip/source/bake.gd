extends SceneTree
func _initialize():
	call_deferred("bake")
func bake():
	var viewport = SubViewport.new()
	viewport.size = Vector2i(320,320)
	viewport.transparent_bg = true
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var counts = {"idle":50,"walk":43,"attack":40,"die":23}
	for who in ["peanut","hutch"]:
		DirAccess.make_dir_recursive_absolute("res://baked/"+who)
		var rig = Node2D.new()
		rig.set_script(load("res://rig.gd"))
		rig.character = who
		rig.animate = false
		rig.position = Vector2(190,270)
		viewport.add_child(rig)
		for state in counts:
			rig.animation = state
			var sheet = Image.create(2560,2560,false,Image.FORMAT_RGBA8)
			for frame in range(counts[state]):
				rig.sample_pose(frame/30.0)
				await process_frame
				await RenderingServer.frame_post_draw
				var rendered = viewport.get_texture().get_image()
				if rendered.is_empty():
					quit(1)
					return
				sheet.blit_rect(rendered,Rect2i(0,0,320,320),Vector2i((frame%8)*320,(frame/8)*320))
			sheet.save_png("res://baked/%s/%s.png" % [who,state])
			print("BAKED ",who," ",state)
		rig.queue_free()
		await process_frame
	quit()
