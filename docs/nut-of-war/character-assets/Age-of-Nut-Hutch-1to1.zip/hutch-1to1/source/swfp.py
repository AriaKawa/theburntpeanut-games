import zlib,struct,sys
class Bits:
    def __init__(s,d,p=0): s.d=d; s.p=p*8
    def ub(s,n):
        v=0
        for _ in range(n):
            v=(v<<1)|((s.d[s.p>>3]>>(7-(s.p&7)))&1); s.p+=1
        return v
    def sb(s,n):
        if n==0: return 0
        v=s.ub(n); return v-(1<<n) if v&(1<<(n-1)) else v
    def align(s): s.p=(s.p+7)&~7
    @property
    def byte(s): s.align(); return s.p>>3
def load(path):
    raw=open(path,'rb').read()
    body=zlib.decompress(raw[8:]) if raw[:3]==b'CWS' else raw[8:]
    b=Bits(body); n=b.ub(5); [b.sb(n) for _ in range(4)]; p=b.byte+4
    return body,p
def tags(d,p,end=None):
    end=end or len(d)
    while p<end:
        h=struct.unpack_from('<H',d,p)[0]; p+=2; code=h>>6; ln=h&0x3f
        if ln==0x3f: ln=struct.unpack_from('<I',d,p)[0]; p+=4
        yield code,p,ln; p+=ln
        if code==0: break
def matrix(b):
    sx=sy=1.0; r0=r1=0.0
    if b.ub(1): n=b.ub(5); sx=b.sb(n)/65536; sy=b.sb(n)/65536
    if b.ub(1): n=b.ub(5); r0=b.sb(n)/65536; r1=b.sb(n)/65536
    n=b.ub(5); tx=b.sb(n)/20; ty=b.sb(n)/20
    return (sx,r0,r1,sy,tx,ty)
def cstr(d,p):
    e=d.index(b'\0',p); return d[p:e].decode('latin1'),e+1
def place2(d,p,ln,v3=False):
    f=d[p]; p+=1; f2=0
    if v3: f2=d[p]; p+=1
    depth=struct.unpack_from('<H',d,p)[0]; p+=2
    out={'depth':depth,'move':bool(f&1)}
    if v3 and (f2&8 or (f2&16 and f&2)): cn,p=cstr(d,p)
    if f&2: out['char']=struct.unpack_from('<H',d,p)[0]; p+=2
    if f&4:
        b=Bits(d,p); out['m']=matrix(b); p=b.byte
    if f&8:  # color transform with alpha
        b=Bits(d,p); ha=b.ub(1); hm=b.ub(1); n=b.ub(4)
        mul=[b.sb(n) for _ in range(4)] if hm else None; add=[b.sb(n) for _ in range(4)] if ha else None
        out['cx']=(mul,add); p=b.byte
    if f&16: out['ratio']=struct.unpack_from('<H',d,p)[0]; p+=2
    if f&32: out['name'],p=cstr(d,p)
    if f&64: out['clip']=struct.unpack_from('<H',d,p)[0]; p+=2
    return out
def place1(d,p,ln):
    ch,depth=struct.unpack_from('<HH',d,p); b=Bits(d,p+4)
    return {'depth':depth,'char':ch,'m':matrix(b),'move':False}
def timeline(d,p,end):
    frames=[]; disp={}; label=None; labels={}
    for code,tp,ln in tags(d,p,end):
        if code in (26,70):
            o=place2(d,tp,ln,code==70); dp=o['depth']
            if o['move'] and dp in disp:
                e=dict(disp[dp]); e.update({k:v for k,v in o.items() if k!='move'}); disp[dp]=e
            else:
                e={'m':(1,0,0,1,0,0)}; e.update({k:v for k,v in o.items() if k!='move'}); disp[dp]=e
        elif code==4: o=place1(d,tp,ln); disp[o['depth']]=o
        elif code==28: disp.pop(struct.unpack_from('<H',d,tp)[0],None)
        elif code==5: disp.pop(struct.unpack_from('<H',d,tp+2)[0],None)
        elif code==43: label,_=cstr(d,tp); labels[label]=len(frames)
        elif code==1: frames.append({k:dict(v) for k,v in disp.items()})
    return frames,labels
