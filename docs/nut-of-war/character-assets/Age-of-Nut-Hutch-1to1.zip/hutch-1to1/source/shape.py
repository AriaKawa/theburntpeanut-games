import struct,numpy as np,cv2
from swfp import Bits,matrix
def rgb(d,p,alpha):
    if alpha: return tuple(d[p:p+4]),p+4
    return tuple(d[p:p+3])+(255,),p+3
def gradient(d,p,alpha,focal=False):
    b=d[p]; n=b&15; p+=1; cols=[]
    for _ in range(n):
        p+=1; c,p=rgb(d,p,alpha); cols.append(c)
    if focal: p+=2
    return tuple(int(np.mean([c[i] for c in cols])) for i in range(4)),p
def fillstyles(d,p,ver):
    n=d[p]; p+=1
    if n==0xff: n=struct.unpack_from('<H',d,p)[0]; p+=2
    out=[]
    for _ in range(n):
        t=d[p]; p+=1
        if t==0: c,p=rgb(d,p,ver>=3); out.append(c)
        elif t in (0x10,0x12,0x13):
            b=Bits(d,p); matrix(b); p=b.byte; c,p=gradient(d,p,ver>=3,t==0x13); out.append(c)
        elif t in (0x40,0x41,0x42,0x43):
            p+=2; b=Bits(d,p); matrix(b); p=b.byte; out.append((128,128,128,0))
        else: raise ValueError(t)
    return out,p
def linestyles(d,p,ver):
    n=d[p]; p+=1
    if n==0xff: n=struct.unpack_from('<H',d,p)[0]; p+=2
    out=[]
    for _ in range(n):
        w=struct.unpack_from('<H',d,p)[0]; p+=2
        if ver==4:
            f1,f2=d[p],d[p+1]; p+=2
            if (f2&0x30)>>4==2: p+=2
            if f1&8:
                p+=1; t=d[p]
                fs,p=fillstyles(d,p-1+0,4) if False else (None,p)
                # fill-typed line: read single fill style
                t=d[p]; p+=1
                if t==0: c,p=rgb(d,p,True)
                else:
                    b=Bits(d,p); matrix(b); p=b.byte; c,p=gradient(d,p,True,t==0x13)
                out.append((w,c)); continue
            c,p=rgb(d,p,True)
        else: c,p=rgb(d,p,ver>=3)
        out.append((w,c))
    return out,p
def parse(code,tp,ln,d):
    ver={2:1,22:2,32:3,83:4}[code]
    p=tp+2; b=Bits(d,p); n=b.ub(5); bounds=[b.sb(n)/20 for _ in range(4)]; p=b.byte
    if ver==4:
        b=Bits(d,p); n=b.ub(5); [b.sb(n) for _ in range(4)]; p=b.byte+1
    fills,p=fillstyles(d,p,ver); lines,p=linestyles(d,p,ver)
    b=Bits(d,p); nf=b.ub(4); nl=b.ub(4)
    x=y=0; f0=f1=ln_=0; edges=[]  # (fills list, lines list, segs)
    base_f=0; groups=[(fills,lines)]; gi=0
    segs=[]
    while True:
        if b.ub(1)==0:
            fl=b.ub(5)
            if fl==0: break
            if fl&1: n=b.ub(5); x=b.sb(n); y=b.sb(n)
            if fl&2: f0=b.ub(nf)
            if fl&4: f1=b.ub(nf)
            if fl&8: ln_=b.ub(nl)
            if fl&16:
                b.align(); fills,q=fillstyles(d,b.byte,ver); lines,q=linestyles(d,q,ver)
                b=Bits(d,q); nf=b.ub(4); nl=b.ub(4); groups.append((fills,lines)); gi+=1; f0=f1=ln_=0
        else:
            if b.ub(1):
                n=b.ub(4)+2
                if b.ub(1): dx=b.sb(n); dy=b.sb(n)
                else:
                    if b.ub(1): dx=0; dy=b.sb(n)
                    else: dx=b.sb(n); dy=0
                pts=[(x,y),(x+dx,y+dy)]; x+=dx; y+=dy
            else:
                n=b.ub(4)+2; cx=x+b.sb(n); cy=y+b.sb(n); ax=cx+b.sb(n); ay=cy+b.sb(n)
                t=np.linspace(0,1,9)[:,None]; P0=np.array([x,y]); P1=np.array([cx,cy]); P2=np.array([ax,ay])
                pts=list(map(tuple,((1-t)**2*P0+2*(1-t)*t*P1+t**2*P2))); x,y=ax,ay
            segs.append((gi,f0,f1,ln_,pts))
    return bounds,groups,segs
def render(d,shape,M,canvas,scale):
    """M: affine (a,b,c,d,tx,ty) in px; draws onto float RGBA canvas (premult on white not used)"""
    code,tp,ln=shape; bounds,groups,segs=parse(code,tp,ln,d)
    A=np.array([[M[0],M[2],M[4]],[M[1],M[3],M[5]]])*scale
    def tr(pts):
        P=np.array(pts,float)/20; return (P@A[:,:2].T+A[:,2])
    H,W=canvas.shape[:2]
    for gi,(fills,lines) in enumerate(groups):
        for fi in range(1,len(fills)+1):
            col=fills[fi-1]
            S=[tr(s[4]) for s in segs if s[0]==gi and (s[1]==fi or s[2]==fi)]
            if not S or col[3]==0: continue
            # even-odd scanline via polylines into mask using XOR fill trick
            mask=np.zeros((H,W),np.uint8)
            ys=np.arange(H)+0.5
            segl=np.concatenate([np.stack([s[:-1],s[1:]],1) for s in S])  # (N,2,2)
            y0=segl[:,0,1]; y1=segl[:,1,1]; x0=segl[:,0,0]; x1=segl[:,1,0]
            for yi,yc in enumerate(ys):
                m=((y0<=yc)&(y1>yc))|((y1<=yc)&(y0>yc))
                if not m.any(): continue
                xs=np.sort(x0[m]+(yc-y0[m])*(x1[m]-x0[m])/(y1[m]-y0[m]))
                for a,b_ in zip(xs[0::2],xs[1::2]):
                    a=int(np.ceil(a-0.5)); b_=int(np.floor(b_-0.5))
                    if b_>=a: mask[yi,max(a,0):max(min(b_+1,W),0)]=255
            al=mask[...,None]/255.0*col[3]/255
            canvas[...,:3]=canvas[...,:3]*(1-al)+np.array(col[:3][::-1],float)*al
            canvas[...,3:4]=np.maximum(canvas[...,3:4],al*255)
        for li in range(1,len(lines)+1):
            w,col=lines[li-1]
            th=max(1,int(round(w/20*scale*np.sqrt(abs(M[0]*M[3]-M[1]*M[2])))))
            for s in segs:
                if s[0]==gi and s[3]==li:
                    P=np.round(tr(s[4])*8).astype(np.int32)
                    lay=np.zeros((H,W),np.uint8); cv2.polylines(lay,[P],False,255,th,cv2.LINE_AA,shift=3)
                    al=lay[...,None]/255.0*col[3]/255
                    canvas[...,:3]=canvas[...,:3]*(1-al)+np.array(col[:3][::-1],float)*al
                    canvas[...,3:4]=np.maximum(canvas[...,3:4],al*255)
