import cv2,numpy as np
R=r"C:/Users/Swagg/AppData/Local/Temp/claude/C--Users-Swagg--claude-spares-spare-Xk65bd/361eb09e-cf9d-4075-915a-df6aaa9f6559/scratchpad/rig/"
im=cv2.imread(R+'hutch-aow-parts-v1.png',cv2.IMREAD_UNCHANGED)
a=im[...,3]
n,lab,st,cen=cv2.connectedComponentsWithStats((a>200).astype(np.uint8))
CELL={(1,0):'torso',(3,0):'grip',(0,0):'head',(2,0):'upper',(0,1):'fist',(1,1):'thigh',(2,1):'shin',(3,1):'club'}
def crops():
    out={}
    for i in range(1,n):
        if st[i,4]<2000: continue
        name=CELL[(int(cen[i][0]//384),int(cen[i][1]//512))]
        x,y,w,h=st[i,:4]; P=6
        m=(lab==i).astype(np.uint8); m=cv2.dilate(m,np.ones((3,3),np.uint8))
        c=im.copy(); c[...,3]=np.minimum(c[...,3],m*255)
        out[name]=c[y-P:y+h+P,x-P:x+w+P].copy()
    return out
def rowspan(alpha,y):
    xs=np.where(alpha[y]>128)[0]; return (xs.min(),xs.max()) if len(xs) else None
def limb_joints(c,top_frac=0.5,bot_frac=0.5):
    al=c[...,3]; ys=np.where(al.max(1)>128)[0]; t,b=ys.min(),ys.max()
    s=rowspan(al,t+8); wt=s[1]-s[0]; top=((s[0]+s[1])/2, t+wt*top_frac)
    s=rowspan(al,b-8); wb=s[1]-s[0]; bot=((s[0]+s[1])/2, b-wb*bot_frac)
    return np.array(top),np.array(bot)
