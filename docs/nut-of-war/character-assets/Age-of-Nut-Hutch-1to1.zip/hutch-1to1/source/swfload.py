import sys,struct
from swfp import *
SWF=r"C:/Users/Swagg/AppData/Local/Temp/claude/C--Users-Swagg--claude-spares-spare-Xk65bd/361eb09e-cf9d-4075-915a-df6aaa9f6559/scratchpad/swf/ageofwar.swf"
d,p0=load(SWF)
sprites={}; shapes={}; names={}; kinds={}
for code,tp,ln in tags(d,p0):
    if code==39:
        sid,fc=struct.unpack_from('<HH',d,tp); fr,lb=timeline(d,tp+4,tp+ln); sprites[sid]=(fr,lb); kinds[sid]='sprite'
    elif code in (2,22,32,83):
        sid=struct.unpack_from('<H',d,tp)[0]; shapes[sid]=(code,tp,ln); kinds[sid]='shape'
    elif code in (6,21,35,20,36,90): kinds[struct.unpack_from('<H',d,tp)[0]]='bitmap'
    elif code in (56,76):
        n=struct.unpack_from('<H',d,tp)[0]; q=tp+2
        for _ in range(n):
            cid=struct.unpack_from('<H',d,q)[0]; s,q=cstr(d,q+2); names[s]=cid
def children(sid):
    fr,_=sprites[sid]; return sorted({e['char'] for f in fr for e in f.values() if 'char' in e})
